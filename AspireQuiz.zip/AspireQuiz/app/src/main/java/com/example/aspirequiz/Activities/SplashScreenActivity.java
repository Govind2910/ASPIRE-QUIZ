package com.example.aspirequiz.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.example.aspirequiz.MainActivity;
import com.example.aspirequiz.R;

//public class SplashScreenActivity extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_splash_screen);
//
//        getSupportActionBar().hide();
//
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run () {
//                Intent intent = new Intent(SplashScreenActivity.this, MainActivity.class);
//                startActivity(intent);
//
//            }
//        };
//
//    }
//}


public class SplashScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        getSupportActionBar().hide();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashScreenActivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // finish SplashScreenActivity to prevent user from coming back to it using back button
            }
        }, 2000); // 2000 milliseconds (2 seconds) delay
    }
}