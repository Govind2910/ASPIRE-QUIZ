package com.example.aspirequiz.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.aspirequiz.R;

public class SetsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sets);

        getSupportActionBar().hide();
    }
}